package com.example.newfile;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class SettingsVerify extends Fragment {

    ImageButton nxtbtn1,nxtbtn2,nxtbtn3,nxtbtn4,nxtbtn5,nxtbtn6,nxtbtn7,nxtbtn8,nxtbtn9,nxtbtn10,nxtbtn11,nxtbtn12,nxtbtn13,nxtbtn14,nxtbtn15,nxtbtn16;

    BottomNavigationView bottomNavigationView;
    HomeFragment homeFragment = new HomeFragment();
    SettingsFragment settingsFragment = new SettingsFragment();
    ProfileFragment profileFragment = new ProfileFragment();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_settings_verify, container, false);
        /****/
        nxtbtn1 = view.findViewById(R.id.nxtfill);
        nxtbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn2 = view.findViewById(R.id.nxtfill2);
        nxtbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn3 = view.findViewById(R.id.nxtfill3);
        nxtbtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn4 = view.findViewById(R.id.nxtfill4);
        nxtbtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn5 = view.findViewById(R.id.nxtfill5);
        nxtbtn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn6 = view.findViewById(R.id.nxtfill6);
        nxtbtn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn7 = view.findViewById(R.id.nxtfill7);
        nxtbtn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn8 = view.findViewById(R.id.nxtfill8);
        nxtbtn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn9 = view.findViewById(R.id.nxtfill9);
        nxtbtn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn10 = view.findViewById(R.id.nxtfill10);
        nxtbtn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn11 = view.findViewById(R.id.nxtfill11);
        nxtbtn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn12 = view.findViewById(R.id.nxtfill12);
        nxtbtn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn13 = view.findViewById(R.id.nxtfill13);
        nxtbtn13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn14 = view.findViewById(R.id.nxtfill14);
        nxtbtn14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn15 = view.findViewById(R.id.nxtfill15);
        nxtbtn15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        /****/
        nxtbtn16 = view.findViewById(R.id.nxtfill16);
        nxtbtn16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerify2();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });

        return view;
    }
}