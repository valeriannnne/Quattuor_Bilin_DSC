package com.example.newfile;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class SeetingsVerify4 extends Fragment {


    Button nxtverified;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_seetings_verify4, container, false);
        /****/
        nxtverified = view.findViewById(R.id.nextverified);
        nxtverified.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFill = new SettingsVerified();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFill).commit();
            }
        });
        return view;
    }
}