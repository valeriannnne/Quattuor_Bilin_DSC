package com.example.newfile;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class OpenCategory extends Fragment {

    Button tosubcat;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_open_category, container, false);

        tosubcat = view.findViewById(R.id.buttonn);
        tosubcat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFrag4 = new HomeFragment();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFrag4).commit();
            }
        });

        return view;
    }
}