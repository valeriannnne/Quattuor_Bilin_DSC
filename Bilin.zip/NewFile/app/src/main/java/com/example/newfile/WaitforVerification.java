package com.example.newfile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WaitforVerification extends AppCompatActivity {

    Button toSettings, toHome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waitfor_verification);

        toSettings = findViewById(R.id.toverify);
        toHome = findViewById(R.id.gotohome);

        toSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a login activity on clicking login text.
                Intent intent = new Intent (WaitforVerification.this, Settings.class);
                startActivity(intent);

            }
        });

        toHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WaitforVerification.this, Homepage.class));
            }
        });

    }
}