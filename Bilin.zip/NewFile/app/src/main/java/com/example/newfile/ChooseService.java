package com.example.newfile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class ChooseService extends AppCompatActivity {

    Button tourism,tutorings,food;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_service);

        tutorings = findViewById(R.id.stutoring);
        tourism = findViewById(R.id.stourism);
        food = findViewById(R.id.sfood);

        tutorings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(ChooseService.this, VerifyTutoring.class));
            }
        });

        tourism.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(ChooseService.this, VerifyTourism.class));
            }
        });

        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(ChooseService.this, VerifyFood.class));
            }
        });


    }
}