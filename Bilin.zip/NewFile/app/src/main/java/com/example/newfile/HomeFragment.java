package com.example.newfile;

import android.app.SearchManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    Button mTourism,mFood,mTutoring;
    ImageButton chatbtn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        /** OPEN CHAT **/
        chatbtn = view.findViewById(R.id.tochat);
        chatbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFrag2 = new OpenCategory2();
                FragmentTransaction fm2 = getActivity().getSupportFragmentManager().beginTransaction();
                fm2.replace(R.id.container,mOpenFrag2).commit();
            }
        });

        /** OPEN THE FIRST CATEGORY **/
        mTutoring = view.findViewById(R.id.tutoringbtn);
        mTutoring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFrag4 = new OpenCategory4();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenFrag4).commit();
            }
        });

        /** OPEN THE SECOND CATEGORY **/
        mTourism = view.findViewById(R.id.tourismbtn);
        mTourism.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFrag2 = new OpenCategory2();
                FragmentTransaction fm2 = getActivity().getSupportFragmentManager().beginTransaction();
                fm2.replace(R.id.container,mOpenFrag2).commit();
            }
        });

        /** OPEN THE THIRD CATEGORY **/
        mFood = view.findViewById(R.id.foodbtn);
        mFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenFrag3 = new OpenCategory3();
                FragmentTransaction fm3 = getActivity().getSupportFragmentManager().beginTransaction();
                fm3.replace(R.id.container,mOpenFrag3).commit();
            }
        });

        return view;
    }
}

