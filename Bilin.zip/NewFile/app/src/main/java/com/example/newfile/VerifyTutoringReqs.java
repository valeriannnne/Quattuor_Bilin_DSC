package com.example.newfile;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class VerifyTutoringReqs extends AppCompatActivity {

    Button nextpage;
    ImageView card,vid;
    Button uploadcard,uploadvid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_tutoring_reqs);

        card = findViewById(R.id.imageView11);
        vid = findViewById(R.id.imageView12);
        uploadcard = findViewById(R.id.uploadcardbtn);
        uploadvid = findViewById(R.id.uploadvidbtn);

        /** Request for Camera Permission **/

        if (ContextCompat.checkSelfPermission(VerifyTutoringReqs.this,
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(VerifyTutoringReqs.this,
                    new String[]{
                            Manifest.permission.CAMERA
                    },
                    100);
        }
        // Uploading of Card
        uploadcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Open Camera
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,100);
            }
        });

        /** For switching to next page **/
        nextpage = findViewById(R.id.toverifytutoring);
        nextpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(VerifyTutoringReqs.this, WaitforVerification.class));
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            //Get Capture Image
            Bitmap captureImage = (Bitmap) data.getExtras().get("data");
            //Set Capture Image to ImageView
            card.setImageBitmap(captureImage);
        }
    }
}