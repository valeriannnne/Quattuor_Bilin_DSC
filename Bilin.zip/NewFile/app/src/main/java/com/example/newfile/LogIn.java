package com.example.newfile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LogIn extends AppCompatActivity {

    EditText mEmailSI, mPasswordSI;
    Button msigninbtn;
    TextView mSwitchSignUp, mforgotpassbtn;
    FirebaseAuth mAuth;
    ProgressBar loadingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        mSwitchSignUp = findViewById(R.id.switchsignup);
        mEmailSI = findViewById(R.id.EmailSI);
        mPasswordSI = findViewById(R.id.PasswordSI);
        msigninbtn = findViewById(R.id.signinbtn);
        mforgotpassbtn = findViewById(R.id.forgotpassbtn);
        loadingPB = findViewById(R.id.idPBLoading);

        mAuth = FirebaseAuth.getInstance();

        mSwitchSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(LogIn.this, SignUp.class));
            }
        });

        msigninbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //hiding our progress bar.
                loadingPB.setVisibility(View.VISIBLE);

                //get data
                String email = mEmailSI.getText().toString().trim();
                String password = mPasswordSI.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    mEmailSI.setError("Invalid Email!");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mPasswordSI.setError("Invalid Password!");
                    return;
                }
                if(password.length() < 8){
                    mPasswordSI.setError("Password must not be less than 8 characters.");
                    return;
                }

                //authenticate the user
                mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            // on below line we are hiding our progress bar.
                            loadingPB.setVisibility(View.GONE);
                            // the user is already sign in.
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null){
                                Toast.makeText(LogIn.this, "Successfully logged in!", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(LogIn.this,Homepage.class));
                                finish();
                            }
                        } else {
                            //hiding our progress bar and displaying a toast message.
                            loadingPB.setVisibility(View.GONE);
                            Toast.makeText(LogIn.this, "Error!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });


        mforgotpassbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(),ForgotPassword.class));
            }
        });

    }
}