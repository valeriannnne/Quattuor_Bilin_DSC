package com.example.newfile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class VerifyTutoring extends AppCompatActivity {

    Button jhs,shs,col;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_tutoring);
        shs = findViewById(R.id.shsbtn);
        jhs = findViewById(R.id.jhsbtn);
        col = findViewById(R.id.collegebtn);

        shs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(VerifyTutoring.this, VerifyTutoringReqs.class));
            }
        });

        jhs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(VerifyTutoring.this, VerifyTutoringReqs.class));
            }
        });

        col.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a sign up activity on clicking sign up text.
                startActivity(new Intent(VerifyTutoring.this, VerifyTutoringReqs.class));
            }
        });
    }
}