package com.example.newfile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.newfile.databinding.ActivityMainBinding;
import com.google.android.gms.common.api.internal.RegisterListenerMethod;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class SignUp extends AppCompatActivity {

    //////////////////////////////

    //////////////////////////////

    EditText mNameSU,mEmailSU,mPasswordSU;
    TextView mSwitchSignIn;
    Button mSignUpBtn;
    FirebaseAuth mAuth;
    DatabaseReference reference;
    ProgressBar loadingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mSwitchSignIn = findViewById(R.id.switchsignin);
        mSignUpBtn = findViewById(R.id.signupbtn);
        mNameSU = findViewById(R.id.NameSU);
        mEmailSU = findViewById(R.id.EmailSU);
        mPasswordSU = findViewById(R.id.PasswordSU);
        loadingPB = findViewById(R.id.idPBLoading);

        mAuth = FirebaseAuth.getInstance();

        mSwitchSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // opening a login activity on clicking login text.
                startActivity(new Intent(SignUp.this, LogIn.class));
            }
        });

        mSignUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                // hiding our progress bar.
                loadingPB.setVisibility(View.VISIBLE);
                //getting data
                String email = mEmailSU.getText().toString().trim();
                String password = mPasswordSU.getText().toString().trim();
                String name = mNameSU.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    mEmailSU.setError("Email is required.");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mPasswordSU.setError("Password is Required.");
                    return;
                }
                else if(password.length() < 8){
                    mPasswordSU.setError("Password must consist of at least 8 characters.");
                    return;
                }
                if(TextUtils.isEmpty(name)){
                    mNameSU.setError("Invalid Name!");
                    return;
                }

                mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            // in on success method we are hiding our progress bar and opening a OTP activity.
                            loadingPB.setVisibility(View.GONE);
                            Toast.makeText(SignUp.this, "Profile created successfully.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), OTP.class);
                            startActivity(intent);
                            finish();
                        }else {
                            // in else condition we are displaying a failure toast message.
                            loadingPB.setVisibility(View.GONE);
                            Toast.makeText(SignUp.this, "Error creating profile." + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });


            }
        });
    }



}

