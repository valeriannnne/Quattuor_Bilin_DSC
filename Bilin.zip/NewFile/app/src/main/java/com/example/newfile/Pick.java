package com.example.newfile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;

public class Pick extends AppCompatActivity {
    ImageButton mNext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick);

        mNext = findViewById(R.id.nextbtn);
        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // to proceed to the next activity
                startActivity(new Intent(Pick.this, ChooseService.class));
            }
        });


    }
}