package com.example.newfile;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsFragment extends Fragment {
    
    TextView mtoverify;
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


    /** OPEN THE FIRST CATEGORY **/
    View view = inflater.inflate(R.layout.fragment_settings, container, false);
       mtoverify = view.findViewById(R.id.gotoverify);
       mtoverify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment mOpenVerify = new SettingsVerify();
                FragmentTransaction fm4 = getActivity().getSupportFragmentManager().beginTransaction();
                fm4.replace(R.id.container,mOpenVerify).commit();
            }
        });
        return view;

    }
}