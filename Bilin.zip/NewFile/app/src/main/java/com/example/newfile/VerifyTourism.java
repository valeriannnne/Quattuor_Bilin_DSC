package com.example.newfile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VerifyTourism extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_tourism);
    }
}